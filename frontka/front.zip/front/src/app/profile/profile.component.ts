import { Component, OnInit } from '@angular/core';
import {ToursService} from '../tours.service';
import {Tour} from '../models';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {
  constructor(private toursService: ToursService) { }
  tours: Tour[];
  comments: Comment[];
  photo: any;
  username = localStorage.getItem('username');
  ngOnInit(): void {
    this.toursService.getProfile().subscribe(tours => this.tours = tours);
    this.photo = this.toursService.getProfilePhoto().subscribe(photo => {
      if (photo.error){
        alert(photo.error);
      }else{
        this.photo = photo.photo;
      }
      console.log(this.photo);
    });
    console.log(this.tours);
  }

  removeItem(id: number): void {
    // alert(id);
    this.tours = this.tours.filter(x => x.id !== id);
    this.toursService.removeTour(id).subscribe(response => console.log(response));
  }

}
