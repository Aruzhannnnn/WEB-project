export interface Category{
  name: string;
}
export interface Tour{
  id: number;
  category: Category;
  name: string;
  country: string;
  price: number;
  description: string;
  image: string;
}

export interface AuthToken{
  token: string;
}

export interface User{
  username: string;
  email: string;
}

export interface Comment{
  id: number;
  title: string;
  text: string;
  created_by: User;
}

export interface Photo{
  photo: string;
}
