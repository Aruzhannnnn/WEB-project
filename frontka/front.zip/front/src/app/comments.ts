import {Comment} from './models';

export const COMMENTS: Comment[] = [
  {
    id:  1,
    title: 'akkaka',
    text: 'pppp',
    created_by: 'admin'
  },
  ];
