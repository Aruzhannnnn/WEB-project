import { Component, OnInit } from '@angular/core';
import {Tour, Comment} from '../models';
import {ActivatedRoute} from '@angular/router';
// import {TOURS} from '../tours';
import {ToursService} from '../tours.service';
import {Location} from '@angular/common';


@Component({
  selector: 'app-tour-detail',
  templateUrl: './tour-detail.component.html',
  styleUrls: ['./tour-detail.component.css']
})
export class TourDetailComponent implements OnInit {
  tour ?: Tour;
  constructor(private route: ActivatedRoute,
              private location: Location,
              private toursService: ToursService) {

  }
  comments: Comment[] ;
  public title = '';
  // tslint:disable-next-line:variable-name
  public text = '';

  ngOnInit(): void {
    // this.getRecipe();
    const routeParams = this.route.snapshot.paramMap;
    const IdFromRoute = Number(routeParams.get('id'));
    this.toursService.getTour(IdFromRoute).subscribe(tour => {
      this.tour = tour;
    });
    this.toursService.getFeedbacks(IdFromRoute).subscribe(comments => this.comments = comments);
  }

  goBack(): void {
    this.location.back();
  }
  // tslint:disable-next-line:typedef
  add(){
    return this.toursService.addFeedback( this.tour.id, this.title,  this.text).subscribe(feedback => {
      if (feedback.error){
        alert(feedback.error);
      }else{
        alert('Added');
      }
      window.location.reload();
    });
  }
  saveComment(id): void{
    const newtext = document.getElementById(id) as HTMLInputElement;
    this.toursService.saveComment(id, newtext.value).subscribe(result => {
      if (result.error){
        alert(result.error);
      }
    });
    window.location.reload();
  }
  deleteComment(id): void{
    this.toursService.deleteComment(id).subscribe(res => {
      if (res.error){
        alert(res.error);
      }
    });
    window.location.reload();
  }

}
