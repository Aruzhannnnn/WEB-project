import { Component, OnInit } from '@angular/core';
import {ToursService} from '../tours.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {
  logged = false;
  username = '';
  password = '';

  // tslint:disable-next-line:typedef
  ngOnInit() {
    const token = localStorage.getItem('token');
    if (token) {
      this.logged = true;
    }
  }

  constructor(private toursService: ToursService,
              private location: Location) {
  }

  // tslint:disable-next-line:typedef
  login() {
    console.log('set');
    // this.toursService.login(this.username, this.password).subscribe(data => {
    //   // localStorage.setItem('token', data.token);
    //   // localStorage.setItem('username', 'asd');
    //   console.log(this.username);
    //   this.logged = true;
    //   this.username = '';
    //   this.password = '';
    // });
  }

  // tslint:disable-next-line:typedef
  logout() {
    this.logged = false;
    localStorage.removeItem('token');
  }
}
