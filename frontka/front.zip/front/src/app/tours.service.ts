import {Injectable} from '@angular/core';
import {HttpClient} from '@angular/common/http';
import {Observable, of} from 'rxjs';
import {MessageService} from './message.service';
import {AuthToken, Tour, Comment} from './models';

@Injectable({
  providedIn: 'root'
})
export class ToursService {
  // tslint:disable-next-line:variable-name
  BASE_URl = 'http://127.0.0.1:8000';
  username = '';

  constructor(private messageService: MessageService, private http: HttpClient) {
  }
  logged(): boolean{
    if (localStorage.getItem('token')){
      return true;
    }
    return false;
  }

  login(username, password): Observable<AuthToken>{
    return this.http.post<AuthToken>(`${this.BASE_URl}/api/login`,  {
      username,
      password
   });
  }
  getTours(): Observable<Tour[]> {
    return this.http.get<Tour[]>(this.BASE_URl + '/api/tours/');
  }

  getTour(id: number): Observable<any> {
    return this.http.get<any>(this.BASE_URl + '/api/tours/' + id);
  }

  getFeedbacks(IdFromRoute): Observable<Comment[]>{
    return this.http.get<Comment[]>(this.BASE_URl + '/api/tours/' + IdFromRoute + '/comments');
  }

  // tslint:disable-next-line:variable-name
  addFeedback(id: number, title: string, text: string): Observable<any> {
    return this.http.post<any>(this.BASE_URl + '/api/tours/' + id + '/comments',
      {
       title,
        text
      });
  }
  getProfile(): Observable<Tour[]>{
    return this.http.get<Tour[]>(this.BASE_URl + '/api/profile/');
  }

  removeTour(id): Observable<any>{
    return this.http.post<any>(this.BASE_URl + '/api/tour/' + id + '/remove', {});
  }
  addTour(id): Observable<any>{
    return this.http.post<any>(this.BASE_URl + '/api/tour/' + id + '/add', {});
  }
  saveComment(id, text): Observable<any>{
    return this.http.put<any>(this.BASE_URl + '/api/comments/' + id, {text});
  }
  deleteComment(id): Observable<any>{
    return this.http.delete<any>(this.BASE_URl + '/api/comments/' + id);
  }
  getProfilePhoto(): Observable<any>{
    return this.http.get<any>(this.BASE_URl + '/api/profile_photo/');
  }
}
