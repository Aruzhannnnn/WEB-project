from django.urls import path
from rest_framework_jwt.views import obtain_jwt_token

from .views import test, UserRegisterView, ToursAPIView, tour_details, CommentApiView, comment_edit, profile, \
    remove_tour, add_tour, profile_photo

urlpatterns = [
    path('login', obtain_jwt_token),
    path('register', UserRegisterView.as_view()),

    path('tours/', ToursAPIView.as_view()),
    path('tours/<int:pk>', tour_details),
    path('tours/<int:pk>/comments', CommentApiView.as_view()),

    path('comments/<int:pk>', comment_edit),

    path('profile/', profile),
    path('tour/<int:pk>/add', add_tour),
    path('tour/<int:pk>/remove', remove_tour),
    
    path('profile_photo/', profile_photo),



]
