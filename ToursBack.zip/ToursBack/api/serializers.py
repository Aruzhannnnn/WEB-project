from rest_framework import serializers
from .models import User, Tour, Comment, Profile


class UserSerializer(serializers.Serializer):
    username = serializers.CharField()
    email = serializers.EmailField()


class CategorySerializer(serializers.Serializer):
    name = serializers.CharField()


class UserRegisterSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ('username', 'email', 'password')

    def validate(self, attrs):
        password = attrs['password']
        if not attrs.__contains__('email'):
            raise serializers.ValidationError('email is required')
        email = attrs['email']
        if len(password) < 8:
            raise serializers.ValidationError('Password is too short, minimum length is 8')
        return attrs

    def create(self, validated_data):
        user = User.objects.create_user(username=validated_data['username'],
                                        password=validated_data['password'],
                                        email=validated_data['email'])
        Profile.objects.create(user=user)
        return user


class TourSerializer(serializers.ModelSerializer):
    category = CategorySerializer()

    class Meta:
        model = Tour
        fields = '__all__'


class CommentSerializer(serializers.Serializer):
    id = serializers.IntegerField()
    title = serializers.CharField()
    text = serializers.CharField()
    created_by = UserSerializer()


class CommentCreateSerializer(serializers.ModelSerializer):
    created_by = UserSerializer(required=False)
    on_tour = TourSerializer(required=False)

    def create(self, validated_data):
        comment = Comment.objects.create(
            created_by=self.context['user'],
            on_tour=self.context['tour'],
            title=validated_data['title'],
            text=validated_data['text'],
        )
        comment.save()
        return comment

    class Meta:
        model = Comment
        fields = ['created_by', 'on_tour', 'title', 'text']

class PhotoSerializer(serializers.ModelSerializer):
    class Meta:
        model = User
        fields = ['photo']

        