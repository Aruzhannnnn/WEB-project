from django.http import HttpResponse, JsonResponse
from django.shortcuts import render
from requests import Response
from rest_framework import generics, status
from rest_framework.decorators import api_view, permission_classes
from rest_framework.permissions import IsAuthenticated
from rest_framework.views import APIView

from .models import Tour, Category, User, Comment, Profile
from .serializers import UserRegisterSerializer, UserSerializer, TourSerializer, CommentSerializer, \
    CommentCreateSerializer,PhotoSerializer


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def test(request):
    print(request.user)
    return HttpResponse("ok")


class UserRegisterView(generics.GenericAPIView):
    serializer_class = UserRegisterSerializer

    def post(self, request, *args, **kwargs):
        try:
            serializer = UserRegisterSerializer(data=request.data)
            if serializer.is_valid(raise_exception=True):
                user = serializer.save()
                ser = UserSerializer(instance=user)
                return JsonResponse(ser.data)
        except Exception as e:
            return JsonResponse({'error': str(e)}, status=status.HTTP_404_NOT_FOUND)


class ToursAPIView(APIView):
    def get(self, request):
        print(request.user)
        serializer = TourSerializer(Tour.objects.all(), many=True)
        return JsonResponse(serializer.data, safe=False)


@api_view(['GET'])
def tour_details(request, pk):
    try:
        tour = Tour.objects.get(id=pk)
    except Exception as e:
        return JsonResponse(e, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    ser = TourSerializer(tour)
    return JsonResponse(ser.data, status=status.HTTP_200_OK)


class CommentApiView(APIView):

    @permission_classes([IsAuthenticated, ])
    def post(self, request, pk, *args, **kwargs):
        # if not request.user.is_authenticated:
        #     return JsonResponse({'error': 'Authorization failed, log in with your credentials!'})
        data = self.request.data
        tour = Tour.objects.get(id=pk)
        print(data, tour)
        ser = CommentCreateSerializer(data=data, context={'user': self.request.user, 'tour': tour})
        if ser.is_valid(raise_exception=True):
            ser.save()
            return JsonResponse(ser.data)
        return JsonResponse(ser.errors)
        # data = request.data
        # comment = Comment.objects.create(text=data['text'], author=request.user, on_car_id=pk)
        # ser = CommentSerializer(comment)
        # return JsonResponse(ser.data, safe=False)

    def get(self, request, pk):
        comments = Tour.objects.get(id=pk).comments.all()
        ser = CommentSerializer(comments, many=True)
        return JsonResponse(ser.data, safe=False)


@api_view(['PUT', 'DELETE'])
@permission_classes([IsAuthenticated, ])
def comment_edit(request, pk):
    if request.method == 'PUT':
        try:
            data = request.data['text']
            comment = Comment.objects.get(id=pk)
            if not request.user == comment.created_by:
                return JsonResponse({'error': 'It is not your comment!'}, safe=False)
            comment.text = data
            comment.save()
            ser = CommentSerializer(comment)
            return JsonResponse(ser.data, safe=False)
        except Exception as e:
            return JsonResponse({'error': str(e)}, safe=False)
    elif request.method == 'DELETE':
        try:
            comment = Comment.objects.get(id=pk)
            if not request.user == comment.created_by:
                return JsonResponse({'error': 'It is not your comment!'}, safe=False)
            comment.delete()
            return JsonResponse({'error': "Success delete"}, status=status.HTTP_200_OK)
        except Exception as e:
            return JsonResponse({'error': str(e)}, safe=False)
    return JsonResponse({}, status=status.HTTP_200_OK)


@api_view(['GET'])
@permission_classes([IsAuthenticated])
def profile(request):
    try:
        profile_tours = request.user.profile.tours
    except Profile.DoesNotExist as e:
        return JsonResponse({'error': str(e)})
    serializer = TourSerializer(profile_tours, many=True)
    return JsonResponse(serializer.data, safe=False)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def add_tour(request, pk):
    try:
        tour = Tour.objects.get(id=pk)
    except Exception as e:
        return JsonResponse({'error': e}, status=status.HTTP_400_BAD_REQUEST)
    user = request.user
    try:
        if not user.profile.tours.get(id=tour.id) == Tour.DoesNotExist:
            return JsonResponse({'error': 'This tour is already on your tour list'})
    except Tour.DoesNotExist as e:
        user.profile.tours.add(tour)
        user.profile.save()
    except Exception as e:
        return JsonResponse({'error': e}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    ser = TourSerializer(user.profile.tours, many=True)
    return JsonResponse(ser.data, safe=False)


@api_view(['POST'])
@permission_classes([IsAuthenticated])
def remove_tour(request, pk):
    try:
        tour = Tour.objects.get(id=pk)
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=status.HTTP_400_BAD_REQUEST)
    user = request.user
    try:
        user.profile.tours.remove(tour)
        user.profile.save()
    except Tour.DoesNotExist as e:
        return JsonResponse({'error': 'This tour is not in your tour list'})
    except Exception as e:
        return JsonResponse({'error': str(e)}, status=status.HTTP_500_INTERNAL_SERVER_ERROR)
    ser = TourSerializer(user.profile.tours, many=True)
    return JsonResponse(ser.data, safe=False)

@api_view(['GET'])
@permission_classes([IsAuthenticated])
def profile_photo(request):
    try:
        user = User.objects.get(username=request.user.username)
    except User.DoesNotExist as e:
        return JsonResponse({'error': str(e)})
    ser = PhotoSerializer(user)
    return JsonResponse(ser.data, safe=False)