from django.contrib import admin
from api.models import User, Tour, Category, Comment, Profile

admin.site.register(User)
admin.site.register(Tour)
admin.site.register(Category)
admin.site.register(Comment)
admin.site.register(Profile)
