from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.auth.base_user import BaseUserManager
from django.contrib import auth
# Create your models here.


class User(AbstractUser):
    photo = models.ImageField(upload_to='user-media', blank=True, null=True)
    # photo = models.CharField(max_length=300)
    class Meta:
        verbose_name = 'User'
        verbose_name_plural = 'Users'

    def __str__(self):
        return f"{self.username}"


class Category(models.Model):
    name = models.CharField(max_length=100)

    class Meta:
        verbose_name = "Category"
        verbose_name_plural = "Categories"

    def __str__(self):
        return f'{self.name}'


class Tour(models.Model):
    name = models.CharField(max_length=100)
    category = models.ForeignKey(Category, on_delete=models.CASCADE)
    description = models.CharField(max_length=200)
    country = models.CharField(max_length=100)
    price = models.IntegerField()
    # image = models.ImageField(upload_to='tours', blank=True, null=True)
    image = models.CharField(max_length=300)
    class Meta:
        verbose_name = 'Tour'
        verbose_name_plural = 'Tours'

    def __str__(self):
        return f'{self.name}'


class Comment(models.Model):
    title = models.CharField(max_length=50)
    text = models.CharField(max_length=350)
    on_tour = models.ForeignKey(Tour, on_delete=models.CASCADE, related_name='comments')
    created_by = models.ForeignKey(User, on_delete=models.CASCADE)

    def to_json(self):
        return {
            'title': self.title,
            'created_by': self.created_by
        }

    class Meta:
        verbose_name = 'Comment'
        verbose_name_plural = 'Comments'

    def __str__(self):
        return f"{self.title} | by {self.created_by}"


class Profile(models.Model):
    user = models.OneToOneField(User, on_delete=models.DO_NOTHING)
    tours = models.ManyToManyField(Tour, blank=True)

    class Meta:
        verbose_name = 'Profile'
        verbose_name_plural = 'Profiles'

    def __str__(self):
        return f"{self.user.username}: Profile"
